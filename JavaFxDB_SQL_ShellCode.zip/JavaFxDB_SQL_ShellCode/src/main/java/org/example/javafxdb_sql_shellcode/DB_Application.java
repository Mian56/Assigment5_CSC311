package org.example.javafxdb_sql_shellcode;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import java.io.IOException;


public class DB_Application {

    private Stage primaryStage;

    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setResizable(false);
        showScene1();

    }

    private void showScene1() {

    }
//
//    private void showSplashScreen() {
//        try {
//            Parent root = FXMLLoader.load(getClass().getResource("splash_screen.fxml"));
//            Scene scene = new Scene(root, 850, 560);
//            scene.getStylesheets().add(getClass().getResource("/styling/style.css").toExternalForm()); // Update the path here
//            primaryStage.setScene(scene);
//            primaryStage.show();
//            changeToMainScene();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private void changeToMainScene() {
//        try {
//            Parent newRoot = FXMLLoader.load(getClass().getResource("db_interface_gui.fxml"));
//
//            Scene currentScene = primaryStage.getScene();
//            Parent currentRoot = currentScene.getRoot();
//            currentScene.getStylesheets().clear(); // Clear existing stylesheets to avoid duplication
//            currentScene.getStylesheets().add(getClass().getResource("/styling/style.css").toExternalForm()); // Update the path here
//
//            // Create a fade-out effect
//            FadeTransition fadeOut = new FadeTransition(Duration.seconds(3), currentRoot);
//            fadeOut.setFromValue(1);
//            fadeOut.setToValue(0);
//            fadeOut.setOnFinished(e -> {
//                Scene newScene = new Scene(newRoot, 850, 560);
//                primaryStage.setScene(newScene);
//            });
//
//            fadeOut.play();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }


}