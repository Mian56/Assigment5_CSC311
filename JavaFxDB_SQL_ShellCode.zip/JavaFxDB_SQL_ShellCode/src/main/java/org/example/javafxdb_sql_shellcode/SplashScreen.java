package org.example.javafxdb_sql_shellcode;

public class SplashScreen {
}
