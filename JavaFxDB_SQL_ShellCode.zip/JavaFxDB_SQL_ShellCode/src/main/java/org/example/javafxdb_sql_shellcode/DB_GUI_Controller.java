package org.example.javafxdb_sql_shellcode;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.example.javafxdb_sql_shellcode.db.ConnDbOps;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class DB_GUI_Controller implements Initializable {

    @FXML
    private AnchorPane rootPane;

    private boolean isBlackAndWhite = false; // Track the current theme

    private DB_Application application;


    private final ObservableList<Person> data =
            FXCollections.observableArrayList(
                    new Person(1, "Jacob", "Smith", "CPIS", "CS"),
                    new Person(2, "Jacob2", "Smith1", "CPIS1", "CS")
            );

    @FXML
    TextField first_name, last_name, department, major;
    @FXML
    private TableView<Person> tv;
    @FXML
    private TableColumn<Person, Integer> tv_id;
    @FXML
    private TableColumn<Person, String> tv_fn, tv_ln, tv_dept, tv_major;

    // MenuBar
    @FXML
    private MenuBar menuBar;

    @FXML
    ImageView img_view;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tv_id.setCellValueFactory(new PropertyValueFactory<>("id"));
        tv_fn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        tv_ln.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        tv_dept.setCellValueFactory(new PropertyValueFactory<>("dept"));
        tv_major.setCellValueFactory(new PropertyValueFactory<>("major"));

        tv.setItems(data);

        // Call to update the menu with shortcuts
        updateMenuWithShortcuts(menuBar);
    }

    public void showMainGUI(Stage primaryStage) {
        // Setup your main GUI scene here
        VBox layout = new VBox(tv); // Assuming you want the TableView in the layout


        // Create and style the scene
        Scene scene = new Scene(layout, 800, 600);
        scene.getStylesheets().add(getClass().getResource("/styling/style.css").toExternalForm()); // Update path if necessary

        primaryStage.setScene(scene);
        primaryStage.setTitle("Database Application");
        primaryStage.show();
    }



    @FXML
    protected void addNewRecord() {
        data.add(new Person(
                data.size() + 1,
                first_name.getText(),
                last_name.getText(),
                department.getText(),
                major.getText()
        ));
    }

    @FXML
    protected void clearForm() {
        first_name.clear();
        last_name.clear();
        department.clear();
        major.clear();
    }

    @FXML
    protected void closeApplication() {
        System.exit(0);
    }

    @FXML
    protected void editRecord() {
        Person p = tv.getSelectionModel().getSelectedItem();
        if (p != null) {
            int index = data.indexOf(p);
            Person updatedPerson = new Person();
            updatedPerson.setId(p.getId());
            updatedPerson.setFirstName(first_name.getText());
            updatedPerson.setLastName(last_name.getText());
            updatedPerson.setDept(department.getText());
            updatedPerson.setMajor(major.getText());
            data.set(index, updatedPerson);

            // Update the database as well
            ConnDbOps cdb = new ConnDbOps();
            cdb.updateUser(p.getId(), updatedPerson.getFirstName(), updatedPerson.getLastName(), "phone", "address", "password");
        }
    }

    @FXML
    protected void deleteRecord() {
        Person p = tv.getSelectionModel().getSelectedItem();
        if (p != null) {
            data.remove(p);

            // Delete from the database
            ConnDbOps cdb = new ConnDbOps();
            cdb.deleteUser(p.getId());
        }
    }

    //allows you to change the profile picture
    @FXML
    protected void showImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"));
        File file = fileChooser.showOpenDialog(tv.getScene().getWindow());

        if (file != null) {
            // Display the selected image in the ImageView
            Image image = new Image(file.toURI().toString());
            img_view.setImage(image);
        }
    }

    //shortcuts created
    public void updateMenuWithShortcuts(MenuBar menuBar) {
        // Add menu items with keyboard shortcuts
        Menu fileMenu = new Menu("File");
        MenuItem editItem = new MenuItem("Edit");
        editItem.setAccelerator(KeyCombination.keyCombination("Ctrl+E"));
        editItem.setOnAction(event -> editRecord());

        MenuItem deleteItem = new MenuItem("Delete");
        deleteItem.setAccelerator(KeyCombination.keyCombination("Ctrl+D"));
        deleteItem.setOnAction(event -> deleteRecord());

        fileMenu.getItems().addAll(editItem, deleteItem);
        menuBar.getMenus().add(fileMenu);
    }

    @FXML
    protected void selectedItemTV(MouseEvent mouseEvent) {
        Person p = tv.getSelectionModel().getSelectedItem();
        if (p != null) {
            first_name.setText(p.getFirstName());
            last_name.setText(p.getLastName());
            department.setText(p.getDept());
            major.setText(p.getMajor());
        }
    }

//    I was a bit tired when working on this part because I had trouble initializing the CSS stylesheet.
    public void handlethemebtn() {
        if (isBlackAndWhite) {
            // Remove the black and white class to revert to default theme
            rootPane.getStyleClass().remove("black-and-white");
        } else {
            // Add the black and white class for the new theme
            rootPane.getStyleClass().add("black-and-white");
        }
        isBlackAndWhite = !isBlackAndWhite; // Toggle theme status
    }

}
