package org.example.javafxdb_sql_shellcode;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.util.Duration;

import java.io.IOException;

public class loginscreenController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;


    @FXML
    private Button loginButton;

    // Reference to the main stage
    private Stage primaryStage;

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    // Handle login
    @FXML
    private void handleLoginAction() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Add your login validation logic here
        if (isValidLogin(username, password)) {
            changeToMainScene();
        } else {
            System.out.println("Login failed. Please try again.");
        }
    }

    // Dummy login
    private boolean isValidLogin(String username, String password) {
        // For testing, "a" is the correct username, and "p" is the correct password
        return username.equals("a") && password.equals("p");
    }

    // Load the main screen (db_interface_gui) after login
    private void changeToMainScene() {
        try {
            Parent newRoot = FXMLLoader.load(getClass().getResource("db_interface_gui.fxml"));

            Scene currentScene = primaryStage.getScene();
            Parent currentRoot = currentScene.getRoot();


            // Create a fade-out effect
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(3), currentRoot);
            fadeOut.setFromValue(1);
            fadeOut.setToValue(0);
            fadeOut.setOnFinished(e -> {
                Scene newScene = new Scene(newRoot, 850, 560);
                primaryStage.setScene(newScene);
            });

            fadeOut.play();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
