package org.example.javafxdb_sql_shellcode;

import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import org.example.javafxdb_sql_shellcode.db.ConnDbOps;

import java.io.IOException;
import java.util.Scanner;

public class App extends Application {

    private static Scene scene;
    private Stage primaryStage;
    private static ConnDbOps cdbop;
    private static boolean guiStarted = false; // Prevents re-launching the GUI

    public static void main(String[] args) {
        cdbop = new ConnDbOps();
        Scanner scan = new Scanner(System.in);

        char input;
        do {
            System.out.println(" ");
            System.out.println("============== Menu ==============");
            System.out.println("| To start GUI,           press 'g' |");
            System.out.println("| To connect to DB,       press 'c' |");
            System.out.println("| To display all users,   press 'a' |");
            System.out.println("| To insert to the DB,    press 'i' |");
            System.out.println("| To query by name,       press 'q' |");
            System.out.println("| To exit,                press 'e' |");
            System.out.println("===================================");
            System.out.print("Enter your choice: ");
            input = scan.next().charAt(0);

            switch (input) {
                case 'g':
                    if (!guiStarted) {
                        guiStarted = true;
                        launch(args); // Launch the GUI
                    } else {
                        System.out.println("GUI is already running.");
                    }
                    break;

                case 'c':
                    cdbop.connectToDatabase();
                    break;

                case 'a':
                    cdbop.listAllUsers();
                    break;

                case 'i':
                    System.out.print("Enter Name: ");
                    String name = scan.next();
                    System.out.print("Enter Email: ");
                    String email = scan.next();
                    System.out.print("Enter Phone: ");
                    String phone = scan.next();
                    System.out.print("Enter Address: ");
                    String address = scan.next();
                    System.out.print("Enter Password: ");
                    String password = scan.next();
                    cdbop.insertUser(name, email, phone, address, password);
                    break;

                case 'q':
                    System.out.print("Enter the name to query: ");
                    String queryName = scan.next();
                    cdbop.queryUserByName(queryName);
                    break;

                case 'e':
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
            System.out.println(" ");
        } while (input != 'e');

        scan.close();
    }

    public static void setRoot(String primary) {
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setResizable(false);

        DB_Application application = new DB_Application();
        application.start(primaryStage); // Pass primaryStage to DB_Application


        showSplashScreen();
    }

    private void showSplashScreen() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("splash_screen.fxml"));
            Scene scene = new Scene(root, 850, 560);
            scene.getStylesheets().add("style.css");
            primaryStage.setScene(scene);
            primaryStage.show();
            changeToLogINScene();
//            changeToMainScene();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //after splash screen login is displayed

    private void changeToLogINScene() {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("loginscreen.fxml"));
            Parent newRoot = loader.load();


            // Get the controller instance and set the primary stage
            loginscreenController controller = loader.getController();
            controller.setPrimaryStage(primaryStage);

            Scene currentScene = primaryStage.getScene();
            Parent currentRoot = currentScene.getRoot();


            // Create a fade-out effect
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(3), currentRoot);
            fadeOut.setFromValue(1);
            fadeOut.setToValue(0);
            fadeOut.setOnFinished(e -> {
                Scene newScene = new Scene(newRoot, 850, 560);
                primaryStage.setScene(newScene);
            });

            fadeOut.play();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
